/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package view;


import bd.ConectaDB;
import beans.Articulo;
import beans.Tipo_articulo;
import beans.dao.impl.DaoArticulo;
import beans.dao.impl.DaoTipo_articulo;
import beans.impl.DaoArticulosImpl;
import beans.impl.DaoTipoArticuloImpl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Hernanadez
 */
public class libro extends javax.swing.JInternalFrame {
    DaoArticulo daoArticulo = new DaoArticulosImpl();
    DaoTipo_articulo daoTipo_articulo = new DaoTipoArticuloImpl();
        private SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");  // Definición de dateFormat

    /**
     * Creates new form FormMantDepartamento
     */
    public libro() {
        initComponents();
        dt.addColumn("ISBN");
        dt.addColumn("TITULO");
        dt.addColumn("AUTOR");
        dt.addColumn("EDICION");
        dt.addColumn("FECHA_INGRESO");
        dt.addColumn("EJEMPLAR");
        dt.addColumn("TIPO_LIBRO");
        dt.addColumn("ESTADO");
        
        DefaultTableModel modelo = (DefaultTableModel) tblLibros.getModel();
;
        tblLibros.setModel(dt);
        }
    
    
    
    public void limpiartabla(){
    
    dt.setRowCount(0);
    
    }
public void limpiar_campos()
{
    jTextField1.setText("");
    jTextField2.setText("");
    jTextField3.setText("");
    jTextField4.setText("");
    jTextField5.setText("");
    jTextField6.setText("");
    jTextField7.setText("");
    jTextField8.setText("");
       
}

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        dialogBusquedaCategoriaArticluos = new javax.swing.JDialog();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblDialogTipoArticulo = new javax.swing.JTable();
        jCalendar1 = new com.toedter.calendar.JCalendar();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblLibros = new javax.swing.JTable();
        btnNuevo = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnGrabar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtestado = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jTextField8 = new javax.swing.JTextField();
        btnGrabar1 = new javax.swing.JButton();

        tblDialogTipoArticulo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblDialogTipoArticulo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tblDialogTipoArticuloMousePressed(evt);
            }
        });
        jScrollPane2.setViewportView(tblDialogTipoArticulo);

        javax.swing.GroupLayout dialogBusquedaCategoriaArticluosLayout = new javax.swing.GroupLayout(dialogBusquedaCategoriaArticluos.getContentPane());
        dialogBusquedaCategoriaArticluos.getContentPane().setLayout(dialogBusquedaCategoriaArticluosLayout);
        dialogBusquedaCategoriaArticluosLayout.setHorizontalGroup(
            dialogBusquedaCategoriaArticluosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dialogBusquedaCategoriaArticluosLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 568, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        dialogBusquedaCategoriaArticluosLayout.setVerticalGroup(
            dialogBusquedaCategoriaArticluosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dialogBusquedaCategoriaArticluosLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        setClosable(true);

        tblLibros.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblLibros.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tblLibrosMousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(tblLibros);

        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/icono_nuevo1.jpg"))); // NOI18N
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        btnModificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/icono_modificar.png"))); // NOI18N
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnGrabar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/icono_guardar1.png"))); // NOI18N
        btnGrabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGrabarActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("Agregar Libro ");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(218, 218, 218)
                .addComponent(jLabel5)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addComponent(jLabel5)
                .addGap(0, 12, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Ediciòn");
        jLabel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Fecha Ingreso");
        jLabel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setText("ISBN ");
        jLabel8.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtestado.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtestado.setText("Titulo");
        txtestado.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Autor ");
        jLabel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setText("Ejemplar");
        jLabel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("Tipo de libro");
        jLabel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setText("Estado");
        jLabel7.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        btnGrabar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/lupa.jpg"))); // NOI18N
        btnGrabar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGrabar1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel8)
                                            .addComponent(txtestado))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jTextField1)
                                            .addComponent(jTextField2))
                                        .addGap(93, 93, 93))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(btnGrabar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(btnGrabar1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addComponent(jLabel1))
                                        .addGap(0, 0, Short.MAX_VALUE)))
                                .addGap(45, 45, 45))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 58, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jTextField4, javax.swing.GroupLayout.DEFAULT_SIZE, 96, Short.MAX_VALUE)
                                    .addComponent(jTextField3))
                                .addGap(92, 92, 92)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel6))
                                .addGap(39, 39, 39)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel7)
                                        .addGap(59, 59, 59)
                                        .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addGap(18, 18, 18)
                                        .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(63, 63, 63))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnNuevo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnGrabar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnModificar)
                    .addComponent(btnGrabar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtestado)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(7, 7, 7)
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel6)
                                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7)
                                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addGap(24, 24, 24)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tblLibrosMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblLibrosMousePressed
       
    }//GEN-LAST:event_tblLibrosMousePressed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        // Asumiendo que tienes una clase ConectaDB que maneja la conexión a la base de datos.
Connection cn = ConectaDB.conexion();
try {
    // Crear una declaración para ejecutar la consulta SQL.
    Statement st = cn.createStatement();
    
    // Ejecutar la consulta para obtener el máximo ID de la tabla Libros.
    ResultSet rs = st.executeQuery("SELECT MAX(ISBN) FROM Libros");
    
    // Verificar si se encontraron resultados.
    if (rs.next()) {
        // Obtener el máximo ID y sumar 1 para el nuevo ID.
        String nuevoISBN = rs.getString(1);
        int nuevoNumero = Integer.parseInt(nuevoISBN.substring(3)) + 1;
        jTextField1.setText("ISBN-" + nuevoNumero);
    } else {
        // Si no se encontraron resultados, establecer el ID inicial.
        jTextField1.setText("ISBN-1");
    }
    
    // Limpiar los otros campos de texto.
    jTextField1.setText("");
    jTextField2.setText("");
    jTextField3.setText("");
    jTextField4.setText("");
    jTextField5.setText("");
    jTextField6.setText("");
    jTextField7.setText("");
    jTextField8.setText("");
    
    // Cerrar la conexión a la base de datos.
    cn.close();
    
    // Limpiar la tabla (asumiendo que tienes un método limpiartabla para esto).
    limpiartabla();
    
} catch (Exception ex) {
    // Mostrar un mensaje de error si ocurre una excepción.
    JOptionPane.showMessageDialog(this, ex.getMessage());
}

    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnGrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGrabarActionPerformed
            // Asumiendo que tienes una clase ConectaDB que maneja la conexión a la base de datos.
            
            if(jTextField1.getText().isEmpty()){
                JOptionPane.showMessageDialog(null, "Campo ISBN no puede ser vacio");
            }else{
                
            
Connection cn = ConectaDB.conexion();
try {
    // Preparar la declaración SQL para insertar datos en Libros.
    PreparedStatement pst = cn.prepareStatement("INSERT INTO Libros (ISBN, titulo, autor_codigo, edicion, fecha_edicion, numero_ejemplar, tipo_codigo, estado) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    
    // Establecer los valores de los parámetros en la declaración preparada.
    pst.setInt(1, Integer.parseInt(jTextField1.getText()));          // Campo de texto para el ISBN
    pst.setString(2, jTextField2.getText());      // Campo de texto para el Título
    pst.setInt(3, Integer.parseInt(jTextField3.getText())); // Campo de texto para el Código del Autor
    pst.setInt(4, Integer.parseInt(jTextField4.getText()));         // Campo de texto para la Edición
    pst.setString(5, jTextField5.getText());         // Campo de texto para la Fecha de Edición
    pst.setInt(6, Integer.parseInt(jTextField6.getText()));       // Campo de texto para el Número de Ejemplar
    pst.setInt(7, Integer.parseInt(jTextField7.getText())); // Campo de texto para el Código del Tipo
    pst.setString(8, jTextField8.getText());              // Campo de texto para el Estado
    
    // Ejecutar la declaración SQL.
    pst.executeUpdate();
    
    // Mostrar un mensaje de éxito.
    JOptionPane.showMessageDialog(this, "Datos guardados con éxito");
    
    // Cerrar la conexión a la base de datos.
    cn.close();
    
    // Limpiar los campos de texto (asumiendo que tienes un método limpiaCampos para esto).
    limpiar_campos();

} catch (Exception ex) {
    // Mostrar un mensaje de error si ocurre una excepción.
    JOptionPane.showMessageDialog(this, ex.getMessage());
}
            }

    }//GEN-LAST:event_btnGrabarActionPerformed

    private void tblDialogTipoArticuloMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblDialogTipoArticuloMousePressed
        
    }//GEN-LAST:event_tblDialogTipoArticuloMousePressed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        // Asumiendo que tienes una clase ConectaDB que maneja la conexión a la base de datos.
Connection cn = ConectaDB.conexion();
try {
    // Preparar la declaración SQL para actualizar datos en Libros.
    PreparedStatement pst = cn.prepareStatement("UPDATE Libros SET fecha_edicion=?, estado=? WHERE ISBN = ?");
   
    pst.setString(1, jTextField5.getText());  // Campo de texto para el Código del Tipo
    pst.setString(2, jTextField8.getText());             // Campo de texto para el Estado
    pst.setString(3, jTextField1.getText());                   // Campo de texto para el ISBN
    
    // Ejecutar la declaración SQL.
    pst.executeUpdate();
    
    // Mostrar un mensaje de éxito.
    JOptionPane.showMessageDialog(this, "Registro editado con éxito");
    
    // Cerrar la conexión a la base de datos.
    cn.close();
    
    // Limpiar los campos de texto (asumiendo que tienes un método limpiaCampos para esto).
    limpiar_campos();

} catch (Exception ex) {
    // Mostrar un mensaje de error si ocurre una excepción.
    JOptionPane.showMessageDialog(this, ex.getMessage());
}

    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnGrabar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGrabar1ActionPerformed
        Connection cn = ConectaDB.conexion();
try {
    // Prepara la consulta SQL para seleccionar todos los datos de la tabla Libros
    PreparedStatement pst = cn.prepareStatement("SELECT ISBN, titulo, autor_codigo, edicion, fecha_edicion, numero_ejemplar, tipo_codigo, estado FROM Libros");

    // Ejecuta la consulta
    ResultSet rs = pst.executeQuery();

    // Limpia la tabla antes de agregar los datos (asumiendo que dt es el modelo de datos de la tabla)
    dt.setRowCount(0);

    // Mientras haya resultados, agrega cada fila a la tabla
    while (rs.next()) {
        dt.addRow(new Object[]{
            rs.getString("ISBN"),
            rs.getString("titulo"),
            rs.getInt("autor_codigo"),
            rs.getString("edicion"),
            rs.getDate("fecha_edicion"),
            rs.getInt("numero_ejemplar"),
            rs.getInt("tipo_codigo"),
            rs.getString("estado")
        });
    }

    // Si no se encontraron resultados, muestra un mensaje
    if (dt.getRowCount() == 0) {
        JOptionPane.showMessageDialog(this, "No se encontraron registros en la tabla de libros.");
    }

    // Cierra la conexión
    cn.close();
} catch (Exception ex) {
    JOptionPane.showMessageDialog(this, ex.getMessage());
}

    }//GEN-LAST:event_btnGrabar1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnGrabar;
    private javax.swing.JButton btnGrabar1;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JDialog dialogBusquedaCategoriaArticluos;
    private com.toedter.calendar.JCalendar jCalendar1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTable tblDialogTipoArticulo;
    private javax.swing.JTable tblLibros;
    private javax.swing.JLabel txtestado;
    // End of variables declaration//GEN-END:variables
    DefaultTableModel dt = new DefaultTableModel();
    DefaultTableModel dtDialogTipoArticulo = new DefaultTableModel();
   
}
