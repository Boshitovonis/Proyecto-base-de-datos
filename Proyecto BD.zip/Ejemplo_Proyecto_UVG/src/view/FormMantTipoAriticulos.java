/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package view;

import bd.ConectaDB;
import beans.Tipo_articulo;
import beans.dao.impl.DaoTipo_articulo;
import beans.impl.DaoTipoArticuloImpl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Hernanadez
 */
public class FormMantTipoAriticulos extends javax.swing.JInternalFrame {
    DaoTipo_articulo  daoTipoArticulo   = new DaoTipoArticuloImpl();
    /**
     * Creates new form FormMantDepartamento
     */
    public FormMantTipoAriticulos() {
        initComponents();
        dt.addColumn("CODIGO");
        dt.addColumn("NOMBRE");
        
   DefaultTableModel modelo = (DefaultTableModel) tblMantTipoArticulos.getModel();
;
        tblMantTipoArticulos.setModel(dt);
        }
public void limpiartabla(){
    
    dt.setRowCount(0);
    
    }
public void limpiar_campos()
{
    txtCodigo.setText("");
    txtNombre1.setText("");
       
}
public void obtieneCodigo()
{
    int cod = daoTipoArticulo.getCodigo();
    cod = cod+1;
    txtCodigo.setText(String.valueOf(cod));
}
public void limpiaCampos()
{
    txtCodigo.setText("");
    txtCodigo.setText("");

}
public void editableCodigo()
{
    txtCodigo.setEditable(false);
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tblMantTipoArticulos = new javax.swing.JTable();
        btnNuevo = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        txtNombre1 = new javax.swing.JTextField();
        txtCodigo = new javax.swing.JTextField();
        btnGrabar = new javax.swing.JButton();
        btnGrabar1 = new javax.swing.JButton();

        setClosable(true);

        tblMantTipoArticulos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblMantTipoArticulos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tblMantTipoArticulosMousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(tblMantTipoArticulos);

        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/icono_nuevo1.jpg"))); // NOI18N
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        btnModificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/icono_modificar.png"))); // NOI18N
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/icono_eliminar3.png"))); // NOI18N
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("AUTOR");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(124, 124, 124)
                .addComponent(jLabel5)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("CODIGO:");
        jLabel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("NOMBRE:");
        jLabel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtNombre1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N

        btnGrabar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/icono_guardar1.png"))); // NOI18N
        btnGrabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGrabarActionPerformed(evt);
            }
        });

        btnGrabar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/lupa.jpg"))); // NOI18N
        btnGrabar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGrabar1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jSeparator1)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 12, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnGrabar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnGrabar1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtNombre1)
                                    .addComponent(txtCodigo))))
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnNuevo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnModificar)
                    .addComponent(btnGrabar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnGrabar1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtCodigo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txtNombre1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(28, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tblMantTipoArticulosMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblMantTipoArticulosMousePressed
        int index = tblMantTipoArticulos.getSelectedRow();
        txtCodigo.setText(String.valueOf(tblMantTipoArticulos.getValueAt(index, 0)));
        txtCodigo.setText(String.valueOf(tblMantTipoArticulos.getValueAt(index, 1)));
    }//GEN-LAST:event_tblMantTipoArticulosMousePressed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        Connection cn = ConectaDB.conexion();
        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery("SELECT MAX(idautor) FROM autores");
            if (rs.next()) {
            
                int nuevoID = rs.getInt(1) + 1;
                txtCodigo.setText(String.valueOf(nuevoID));
            } else {
           
            txtCodigo.setText("1");
            }
        
      
              txtCodigo.setText("");
              txtNombre1.setText("");
     
            cn.close();
            limpiartabla();
        
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }

    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
            // Asumiendo que tienes una clase ConectaDB que maneja la conexión a la base de datos.
Connection cn = ConectaDB.conexion();
try {
    // Preparar la declaración SQL para eliminar datos en Autores.
    PreparedStatement pst = cn.prepareStatement("DELETE FROM Autores WHERE codigo = ?");
    
    // Establecer el valor del parámetro en la declaración preparada.
    pst.setInt(1, Integer.parseInt(txtCodigo.getText()));  // Campo de texto para el ID
    
    // Ejecutar la declaración SQL.
    pst.executeUpdate();
    
    // Mostrar un mensaje de éxito.
    JOptionPane.showMessageDialog(this, "Registro eliminado con éxito");
    
    // Cerrar la conexión a la base de datos.
    cn.close();
    
    // Limpiar los campos de texto (asumiendo que tienes un método limpiarCampos para esto).
    limpiaCampos();
    
    // Limpiar la tabla (asumiendo que tienes un método limpiarTabla para esto).
    limpiartabla();

} catch (Exception ex) {
    // Mostrar un mensaje de error si ocurre una excepción.
    JOptionPane.showMessageDialog(this, ex.getMessage());
}

    }//GEN-LAST:event_btnEliminarActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        // Asumiendo que tienes una clase ConectaDB que maneja la conexión a la base de datos.
Connection cn = ConectaDB.conexion();
try {
    // Preparar la declaración SQL para actualizar datos en Autores, excluyendo el campo de llave primaria.
    PreparedStatement pst = cn.prepareStatement("UPDATE Autores SET nombre=? WHERE codigo = ?");
    
    // Establecer los valores de los parámetros en la declaración preparada.
    pst.setString(1, txtCodigo.getText());         // Campo de texto para el Nombre
    pst.setString(2, txtNombre1.getText());            // Campo de texto para el ID
    
    // Ejecutar la declaración SQL.
    pst.executeUpdate();
    
    // Mostrar un mensaje de éxito.
    JOptionPane.showMessageDialog(this, "Registro editado con éxito");
    
    // Cerrar la conexión a la base de datos.
    cn.close();
    
    // Limpiar los campos de texto (asumiendo que tienes un método limpiaCampos para esto).
    limpiaCampos();

} catch (Exception ex) {
    // Mostrar un mensaje de error si ocurre una excepción.
    JOptionPane.showMessageDialog(this, ex.getMessage());
}
    }//GEN-LAST:event_btnModificarActionPerformed

    private void btnGrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGrabarActionPerformed
        // Asumiendo que tienes una clase ConectaDB que maneja la conexión a la base de datos.
Connection cn = ConectaDB.conexion();
try {
    // Preparar la declaración SQL para insertar datos en Autores.
    PreparedStatement pst = cn.prepareStatement("INSERT INTO Autores (codigo, nombre) VALUES (?, ?)");
    
    // Establecer los valores de los parámetros en la declaración preparada.
    pst.setString(1, txtCodigo.getText());          // Campo de texto para el código (ID)
    pst.setString(2, txtNombre1.getText());      // Campo de texto para el Nombre
    
    // Ejecutar la declaración SQL.
    pst.executeUpdate();
    
    // Mostrar un mensaje de éxito.
    JOptionPane.showMessageDialog(this, "Datos guardados con éxito");
    
    // Cerrar la conexión a la base de datos.
    cn.close();
    
    // Limpiar los campos de texto (asumiendo que tienes un método limpiaCampos para esto).
    limpiaCampos();

} catch (Exception ex) {
    // Mostrar un mensaje de error si ocurre una excepción.
    JOptionPane.showMessageDialog(this, ex.getMessage());
}


    }//GEN-LAST:event_btnGrabarActionPerformed

    private void btnGrabar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGrabar1ActionPerformed
        
        Connection cn = ConectaDB.conexion();
try {
    // Prepara la consulta SQL para seleccionar todos los datos de la tabla Autores
    PreparedStatement pst = cn.prepareStatement("SELECT codigo, nombre FROM Autores");

    // Ejecuta la consulta
    ResultSet rs = pst.executeQuery();

    // Limpia la tabla antes de agregar los datos (asumiendo que dt es el modelo de datos de la tabla)
    dt.setRowCount(0);

    // Mientras haya resultados, agrega cada fila a la tabla
    while (rs.next()) {
        dt.addRow(new Object[]{
            rs.getInt("codigo"),
            rs.getString("nombre")
        });
    }

    // Si no se encontraron resultados, muestra un mensaje
    if (dt.getRowCount() == 0) {
        JOptionPane.showMessageDialog(this, "No se encontraron registros en la tabla de autores.");
    }

    // Cierra la conexión
    cn.close();
} catch (Exception ex) {
    JOptionPane.showMessageDialog(this, ex.getMessage());
}

    }//GEN-LAST:event_btnGrabar1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGrabar;
    private javax.swing.JButton btnGrabar1;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable tblMantTipoArticulos;
    private javax.swing.JTextField txtCodigo;
    private javax.swing.JTextField txtNombre1;
    // End of variables declaration//GEN-END:variables
    DefaultTableModel dt = new DefaultTableModel();
}
