/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package view;

import java.awt.Dimension;
import javax.swing.ImageIcon;

/**
 *
 * @author Hernanadez
 */
public class Menu extends javax.swing.JFrame {
    private FormManArticulos fma;
    private estado_libro tka;
    private centrouniversitario1 fmm;
    private facultad tt;
    private prestamo rr;
    private libro gg;
    private FormMantTipoAriticulos aa;
   
    /**
     * Creates new form Menu
     */
    public Menu() {
        initComponents();

        this.setExtendedState(MAXIMIZED_BOTH);
    }


 public void showFormMantArticulos() {
        if (fma == null) {
            fma = new FormManArticulos();
            Dimension frameDim = this.getSize();
            Dimension formDim = fma.getSize();
            fma.setLocation((frameDim.width - formDim.width) / 2, (frameDim.height - formDim.height) / 2);
            getContentPane().add(fma);
            fma.setVisible(true);
        } else {
            fma.setVisible(false);
            getContentPane().remove(fma);
            fma = null;
        }
        revalidate();
        repaint();
    }
public void estado_libro() {
        if (tka == null) {
            tka = new estado_libro();
            Dimension frameDim = this.getSize();
            Dimension formDim = tka.getSize();
            tka.setLocation((frameDim.width - formDim.width) / 2, (frameDim.height - formDim.height) / 2);
            getContentPane().add(tka);
            tka.setVisible(true);
        } else {
            tka.setVisible(false);
            getContentPane().remove(tka);
            tka = null;
        }
        revalidate();
        repaint();
    }
public void centrouniversitario1() {
        if (fmm == null) {
            fmm = new centrouniversitario1();
            Dimension frameDim = this.getSize();
            Dimension formDim = fmm.getSize();
            fmm.setLocation((frameDim.width - formDim.width) / 2, (frameDim.height - formDim.height) / 2);
            getContentPane().add(fmm);
            fmm.setVisible(true);
        } else {
            fmm.setVisible(false);
            getContentPane().remove(fmm);
            fmm = null;
        }
        revalidate();
        repaint();
    }
public void facultad() {
        if (tt == null) {
            tt = new facultad();
            Dimension frameDim = this.getSize();
            Dimension formDim = tt.getSize();
            tt.setLocation((frameDim.width - formDim.width) / 2, (frameDim.height - formDim.height) / 2);
            getContentPane().add(tt);
            tt.setVisible(true);
        } else {
            tt.setVisible(false);
            getContentPane().remove(tt);
            tt = null;
        }
        revalidate();
        repaint();
    }
    public void prestamo() {
        if (rr == null) {
            rr = new prestamo();
            Dimension frameDim = this.getSize();
            Dimension formDim = rr.getSize();
            rr.setLocation((frameDim.width - formDim.width) / 2, (frameDim.height - formDim.height) / 2);
            getContentPane().add(rr);
            rr.setVisible(true);
        } else {
            rr.setVisible(false);
            getContentPane().remove(rr);
            rr = null;
        }
        revalidate();
        repaint();
    }
    public void libro() {
        if (gg == null) {
            gg = new libro();
            Dimension frameDim = this.getSize();
            Dimension formDim = gg.getSize();
            gg.setLocation((frameDim.width - formDim.width) / 2, (frameDim.height - formDim.height) / 2);
            getContentPane().add(gg);
            gg.setVisible(true);
        } else {
            gg.setVisible(false);
            getContentPane().remove(gg);
            gg = null;
        }
        revalidate();
        repaint();
    }
    
    public void FormMantTipoArticulos() {
        if (aa == null) {
            aa = new FormMantTipoAriticulos();
            Dimension frameDim = this.getSize();
            Dimension formDim = aa.getSize();
            aa.setLocation((frameDim.width - formDim.width) / 2, (frameDim.height - formDim.height) / 2);
            getContentPane().add(aa);
            aa.setVisible(true);
        } else {
            aa.setVisible(false);
            getContentPane().remove(aa);
            aa = null;
        }
        revalidate();
        repaint();
    }
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu2 = new javax.swing.JMenu();
        jMenu3 = new javax.swing.JMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        jMenuBar2 = new javax.swing.JMenuBar();
        jMenu4 = new javax.swing.JMenu();
        jMenu5 = new javax.swing.JMenu();
        jMenu7 = new javax.swing.JMenu();
        jMenuItem2 = new javax.swing.JMenuItem();
        menuBar = new javax.swing.JMenuBar();
        fileMenu = new javax.swing.JMenu();
        jMenuItem6 = new javax.swing.JMenuItem();
        jMenuItem5 = new javax.swing.JMenuItem();
        exitMenuItem = new javax.swing.JMenuItem();
        jMenu8 = new javax.swing.JMenu();
        jRadioButtonMenuItem1 = new javax.swing.JRadioButtonMenuItem();
        jMenu1 = new javax.swing.JMenu();
        EmpleadosMenuItem1 = new javax.swing.JMenuItem();
        jMenu6 = new javax.swing.JMenu();
        jMenuItem3 = new javax.swing.JMenuItem();

        jMenu2.setText("File");
        jMenuBar1.add(jMenu2);

        jMenu3.setText("Edit");
        jMenuBar1.add(jMenu3);

        jMenuItem1.setText("jMenuItem1");

        jMenu4.setText("File");
        jMenuBar2.add(jMenu4);

        jMenu5.setText("Edit");
        jMenuBar2.add(jMenu5);

        jMenu7.setText("jMenu7");

        jMenuItem2.setText("jMenuItem2");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Libreria UVG");
        setIconImage(new ImageIcon(getClass().getResource("/resources/iconoSisPedidos5.jpg")).getImage());

        fileMenu.setMnemonic('f');
        fileMenu.setText("Libros");

        jMenuItem6.setText("Ingreso de libro");
        jMenuItem6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem6ActionPerformed(evt);
            }
        });
        fileMenu.add(jMenuItem6);

        jMenuItem5.setText("Creacion De Prestamos ");
        jMenuItem5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem5ActionPerformed(evt);
            }
        });
        fileMenu.add(jMenuItem5);

        exitMenuItem.setMnemonic('x');
        exitMenuItem.setText("Salir");
        exitMenuItem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exitMenuItemActionPerformed(evt);
            }
        });
        fileMenu.add(exitMenuItem);

        menuBar.add(fileMenu);

        jMenu8.setText("Autores");

        jRadioButtonMenuItem1.setSelected(true);
        jRadioButtonMenuItem1.setText("Autores ");
        jRadioButtonMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jRadioButtonMenuItem1ActionPerformed(evt);
            }
        });
        jMenu8.add(jRadioButtonMenuItem1);

        menuBar.add(jMenu8);

        jMenu1.setText("Empleados");

        EmpleadosMenuItem1.setText("Personal");
        EmpleadosMenuItem1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                EmpleadosMenuItem1MousePressed(evt);
            }
        });
        EmpleadosMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EmpleadosMenuItem1ActionPerformed(evt);
            }
        });
        jMenu1.add(EmpleadosMenuItem1);

        menuBar.add(jMenu1);

        jMenu6.setText("Univerisdad");

        jMenuItem3.setText("centro universitario");
        jMenuItem3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem3ActionPerformed(evt);
            }
        });
        jMenu6.add(jMenuItem3);

        menuBar.add(jMenu6);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 706, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 281, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void EmpleadosMenuItem1MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_EmpleadosMenuItem1MousePressed
      
    }//GEN-LAST:event_EmpleadosMenuItem1MousePressed

    private void EmpleadosMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EmpleadosMenuItem1ActionPerformed
       showFormMantArticulos();
        
    }//GEN-LAST:event_EmpleadosMenuItem1ActionPerformed

    private void jMenuItem3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem3ActionPerformed
centrouniversitario1();        // TODO add your handling code here:
    }//GEN-LAST:event_jMenuItem3ActionPerformed

    private void exitMenuItemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_exitMenuItemActionPerformed
        System.exit(0);
    }//GEN-LAST:event_exitMenuItemActionPerformed

    private void jMenuItem5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem5ActionPerformed
       prestamo();
    }//GEN-LAST:event_jMenuItem5ActionPerformed

    private void jMenuItem6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem6ActionPerformed
        libro();
    }//GEN-LAST:event_jMenuItem6ActionPerformed

    private void jRadioButtonMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jRadioButtonMenuItem1ActionPerformed
       FormMantTipoArticulos();
    }//GEN-LAST:event_jRadioButtonMenuItem1ActionPerformed

    /**
     * @param args the command line arguments
     */
//    public static void main(String args[]) {
//        /* Set the Nimbus look and feel */
//        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
//        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
//         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
//         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(Menu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
//        //</editor-fold>
//
//        /* Create and display the form */
//        java.awt.EventQueue.invokeLater(new Runnable() {
//            public void run() {
//                new Menu().setVisible(true);
//            }
//        });
//    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem EmpleadosMenuItem1;
    private javax.swing.JMenuItem exitMenuItem;
    private javax.swing.JMenu fileMenu;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenu jMenu6;
    private javax.swing.JMenu jMenu7;
    private javax.swing.JMenu jMenu8;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuBar jMenuBar2;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JMenuItem jMenuItem2;
    private javax.swing.JMenuItem jMenuItem3;
    private javax.swing.JMenuItem jMenuItem5;
    private javax.swing.JMenuItem jMenuItem6;
    private javax.swing.JRadioButtonMenuItem jRadioButtonMenuItem1;
    private javax.swing.JMenuBar menuBar;
    // End of variables declaration//GEN-END:variables


   // FormMantAutores fma;
   // FormMantCategorias fmc;
   // FormMantTiposLibros fmtl;
   // FormManLibros1 fml;
   // FormMantEmpleados fme;
   // FormMantEjemplares fmej;
  //  FormMantUsuarios fmu;
}
