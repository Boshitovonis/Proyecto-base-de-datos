/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package view;

import bd.ConectaDB;
import beans.Articulo;
import beans.Tipo_articulo;
import beans.dao.impl.DaoArticulo;
import beans.dao.impl.DaoTipo_articulo;
import beans.impl.DaoArticulosImpl;
import beans.impl.DaoTipoArticuloImpl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Hernanadez
 */
public class prestamo extends javax.swing.JInternalFrame {
    DaoArticulo daoArticulo = new DaoArticulosImpl();
    DaoTipo_articulo daoTipo_articulo = new DaoTipoArticuloImpl();
    /**
     * Creates new form FormMantDepartamento
     */
    public prestamo() {
        initComponents();
        dt.addColumn("ID");
        dt.addColumn("ID_EMPLEADO");
        dt.addColumn("ID_USUARIO");
        dt.addColumn("FECHA_PRESTAMO");
        dt.addColumn("FECHA_DEVUELVE");
        dt.addColumn("ISBN");
        dt.addColumn("NUMERO_EJEMPLAR");
        
          DefaultTableModel modelo = (DefaultTableModel) tblP.getModel();
;
        tblP.setModel(dt);
        }
    public void limpiartabla(){
    
    dt.setRowCount(0);
    
    }
public void limpiar_campos()
{
    
    txtFechaIngreso.setText("");
    jTextField1.setText("");
    jTextField2.setText("");
    jTextField4.setText("");
    jTextField5.setText("");
    jTextField3.setText("");
    txtPrecioCosto.setText("");
    txtPrecioCosto1.setText("");
    }

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        dialogBusquedaCategoriaArticluos = new javax.swing.JDialog();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblDialogTipoArticulo = new javax.swing.JTable();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblP = new javax.swing.JTable();
        btnNuevo = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnGrabar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtPrecioCosto = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtFechaIngreso = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtestado = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jTextField2 = new javax.swing.JTextField();
        jTextField3 = new javax.swing.JTextField();
        jTextField4 = new javax.swing.JTextField();
        jTextField5 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        txtPrecioCosto1 = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        btnGrabar1 = new javax.swing.JButton();

        tblDialogTipoArticulo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblDialogTipoArticulo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tblDialogTipoArticuloMousePressed(evt);
            }
        });
        jScrollPane2.setViewportView(tblDialogTipoArticulo);

        javax.swing.GroupLayout dialogBusquedaCategoriaArticluosLayout = new javax.swing.GroupLayout(dialogBusquedaCategoriaArticluos.getContentPane());
        dialogBusquedaCategoriaArticluos.getContentPane().setLayout(dialogBusquedaCategoriaArticluosLayout);
        dialogBusquedaCategoriaArticluosLayout.setHorizontalGroup(
            dialogBusquedaCategoriaArticluosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dialogBusquedaCategoriaArticluosLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 568, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        dialogBusquedaCategoriaArticluosLayout.setVerticalGroup(
            dialogBusquedaCategoriaArticluosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dialogBusquedaCategoriaArticluosLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        setClosable(true);

        tblP.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblP.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tblPMousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(tblP);

        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/icono_nuevo1.jpg"))); // NOI18N
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        btnModificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/icono_modificar.png"))); // NOI18N
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/icono_eliminar3.png"))); // NOI18N
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnGrabar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/icono_guardar1.png"))); // NOI18N
        btnGrabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGrabarActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("Creacion de Prestamos ");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(353, 353, 353)
                .addComponent(jLabel5)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Id Empleado");
        jLabel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Fecha prestamo");
        jLabel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Fecha Devuelto");
        jLabel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setText("Estado");
        jLabel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtPrecioCosto.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("Id");
        jLabel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtFechaIngreso.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtFechaIngreso.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtFechaIngresoActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setText("Id Usuario");
        jLabel8.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtestado.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtestado.setText("ISBN");
        txtestado.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jButton1.setText("Buscar activos");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel7.setText("Numero Ejemplar");
        jLabel7.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtPrecioCosto1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N

        jButton2.setText("Buscar total");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Buscar x usuario");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        btnGrabar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/lupa.jpg"))); // NOI18N
        btnGrabar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGrabar1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)
                        .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator1))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(2, 2, 2)
                                        .addComponent(jLabel8)
                                        .addGap(18, 18, 18)
                                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 216, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addComponent(jLabel1)
                                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(26, 26, 26)
                                                .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 194, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(18, 18, 18)
                                                .addComponent(txtFechaIngreso, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel2)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 145, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(83, 83, 83)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel7)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(81, 81, 81)
                                                .addComponent(txtestado)))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(jLabel4)
                                        .addGap(40, 40, 40)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtPrecioCosto, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtPrecioCosto1, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnGrabar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnGrabar1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(27, 27, 27)
                                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton2)
                                .addGap(18, 18, 18)
                                .addComponent(jButton3)))
                        .addContainerGap(169, Short.MAX_VALUE))))
            .addComponent(jScrollPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btnNuevo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnGrabar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(btnModificar)
                            .addComponent(btnGrabar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(12, 12, 12))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1)
                            .addComponent(jButton2)
                            .addComponent(jButton3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(txtFechaIngreso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(9, 9, 9)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(jTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtestado)
                            .addComponent(jTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtPrecioCosto1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtPrecioCosto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTextField5, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(42, 42, 42)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tblPMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblPMousePressed
        
    }//GEN-LAST:event_tblPMousePressed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
        // Asumiendo que tienes una clase ConectaDB que maneja la conexión a la base de datos.
Connection cn = ConectaDB.conexion();
try {
    // Crear una declaración para ejecutar la consulta SQL.
    Statement st = cn.createStatement();
    
    // Ejecutar la consulta para obtener el máximo ID de la tabla Prestamos.
    ResultSet rs = st.executeQuery("SELECT MAX(id) FROM Prestamos");
    
    // Verificar si se encontraron resultados.
    if (rs.next()) {
        // Obtener el máximo ID y sumar 1 para el nuevo ID.
        int nuevoID = rs.getInt(1) + 1;
        txtFechaIngreso.setText(String.valueOf(nuevoID));
    } else {
        // Si no se encontraron resultados, establecer el ID inicial.
        txtFechaIngreso.setText("1");
    }
    
    // Limpiar los otros campos de texto.
 
    txtFechaIngreso.setText("");
    jTextField1.setText("");
    jTextField2.setText("");
    jTextField4.setText("");
    jTextField5.setText("");
    jTextField3.setText("");
    txtPrecioCosto.setText("");
    
    // Cerrar la conexión a la base de datos.
    cn.close();
    
    // Limpiar la tabla (asumiendo que tienes un método limpiartabla para esto).
    limpiartabla();
    
} catch (Exception ex) {
    // Mostrar un mensaje de error si ocurre una excepción.
    JOptionPane.showMessageDialog(this, ex.getMessage());
}

    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnGrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGrabarActionPerformed
    // Asumiendo que tienes una clase ConectaDB que maneja la conexión a la base de datos.
Connection cn = ConectaDB.conexion();
try {
    // Preparar la declaración SQL para insertar datos en Prestamos.
    PreparedStatement pst = cn.prepareStatement("SET IDENTITY_INSERT prestamos ON; INSERT INTO Prestamos (id, empleado_id, usuario_id, fecha_prestamo, fecha_devolucion, ISBN, libro_numero_ejemplar,estado) VALUES (?, ?, ?, ?, ?, ?, ?, 1);SET IDENTITY_INSERT prestamo OFF;");
    
    // Establecer los valores de los parámetros en la declaración preparada.
    pst.setInt(1, Integer.parseInt(txtFechaIngreso.getText()));  // Campo de texto para el ID
    pst.setInt(2, Integer.parseInt(jTextField1.getText()));      // Campo de texto para el ID del Empleado
    pst.setInt(3, Integer.parseInt(jTextField2.getText()));      // Campo de texto para el ID del Usuario
    pst.setString(4, jTextField4.getText());                     // Campo de texto para la Fecha de Préstamo
    pst.setString(5, jTextField5.getText());                     // Campo de texto para la Fecha de Devolución
    pst.setString(6, jTextField3.getText());                     // Campo de texto para el ISBN del Libro
    pst.setInt(7, Integer.parseInt(txtPrecioCosto1.getText())); 
    // Campo de texto para el Número de Ejemplar del Libro
    
    // Ejecutar la declaración SQL.
    pst.executeUpdate();
    
    // Mostrar un mensaje de éxito.
    JOptionPane.showMessageDialog(this, "Datos guardados con éxito");
    
    // Cerrar la conexión a la base de datos.
    cn.close();
    
    // Limpiar los campos de texto (asumiendo que tienes un método limpiarCampos para esto).
    limpiar_campos();

} catch (Exception ex) {
    // Mostrar un mensaje de error si ocurre una excepción.
    JOptionPane.showMessageDialog(this, ex.getMessage());
}


    }//GEN-LAST:event_btnGrabarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
        // Asumiendo que tienes una clase ConectaDB que maneja la conexión a la base de datos.
Connection cn = ConectaDB.conexion();
try {
    // Preparar la declaración SQL para eliminar datos en Prestamos.
    PreparedStatement pst = cn.prepareStatement("DELETE FROM Prestamos WHERE id = ?");
    
    // Establecer el valor del parámetro en la declaración preparada.
    pst.setInt(1, Integer.parseInt(txtFechaIngreso.getText()));  // Campo de texto para el ID del préstamo
    
    // Ejecutar la declaración SQL.
    pst.executeUpdate();
    
    // Mostrar un mensaje de éxito.
    JOptionPane.showMessageDialog(this, "Registro eliminado con éxito");
    
    // Cerrar la conexión a la base de datos.
    cn.close();
    
    // Limpiar los campos de texto (asumiendo que tienes un método limpiarCampos para esto).
    limpiar_campos();
    
    // Limpiar la tabla (asumiendo que tienes un método limpiarTabla para esto).
    limpiartabla();

} catch (Exception ex) {
    // Mostrar un mensaje de error si ocurre una excepción.
    JOptionPane.showMessageDialog(this, ex.getMessage());
}

    }//GEN-LAST:event_btnEliminarActionPerformed

    private void tblDialogTipoArticuloMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblDialogTipoArticuloMousePressed
        
    }//GEN-LAST:event_tblDialogTipoArticuloMousePressed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
        // Asumiendo que tienes una clase ConectaDB que maneja la conexión a la base de datos.
Connection cn = ConectaDB.conexion();
try {
    // Preparar la declaración SQL para actualizar datos en Prestamos.
    PreparedStatement pst = cn.prepareStatement("UPDATE Prestamos SET fecha_devolucion=?, estado=? WHERE id = ?");
   
    pst.setString(1, jTextField5.getText());  // Campo de texto para la Fecha de Devolución
    pst.setString(2, txtPrecioCosto.getText());  // Campo de texto para el Estado
    pst.setInt(3, Integer.parseInt(txtFechaIngreso.getText())); // Campo de texto para el ID del préstamo
    
    // Ejecutar la declaración SQL.
    pst.executeUpdate();
    
    // Mostrar un mensaje de éxito.
    JOptionPane.showMessageDialog(this, "Registro editado con éxito");
    
    // Cerrar la conexión a la base de datos.
    cn.close();
    
    // Limpiar los campos de texto (asumiendo que tienes un método limpiaCampos para esto).
    limpiar_campos();

} catch (Exception ex) {
    // Mostrar un mensaje de error si ocurre una excepción.
    JOptionPane.showMessageDialog(this, ex.getMessage());
}


    }//GEN-LAST:event_btnModificarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
           // Asumiendo que tienes una clase ConectaDB que maneja la conexión a la base de datos.
Connection cn = ConectaDB.conexion();
try {
    // Prepara la consulta SQL para contar los préstamos activos
    String query = "SELECT COUNT(*) AS num_prestamos FROM Prestamos WHERE estado = 1";

    PreparedStatement pst = cn.prepareStatement(query);

    // Ejecuta la consulta
    ResultSet rs = pst.executeQuery();

    // Si hay resultados, muestra el número de préstamos activos
    if (rs.next()) {
        int numPrestamosActivos = rs.getInt("num_prestamos");
        JOptionPane.showMessageDialog(this, "Número de préstamos activos: " + numPrestamosActivos);
    } else {
        // Si no se encuentran resultados, muestra un mensaje
        JOptionPane.showMessageDialog(this, "No se encontraron préstamos activos.");
    }

    // Cierra la conexión
    cn.close();
} catch (Exception ex) {
    JOptionPane.showMessageDialog(this, ex.getMessage());
}


    }//GEN-LAST:event_jButton1ActionPerformed

    private void txtFechaIngresoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtFechaIngresoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtFechaIngresoActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // Asumiendo que tienes una clase ConectaDB que maneja la conexión a la base de datos.
Connection cn = ConectaDB.conexion();
try {
    // Prepara la consulta SQL para contar todos los préstamos
    String query = "SELECT COUNT(*) AS num_prestamos FROM Prestamos";

    PreparedStatement pst = cn.prepareStatement(query);

    // Ejecuta la consulta
    ResultSet rs = pst.executeQuery();

    // Si hay resultados, muestra el número total de préstamos
    if (rs.next()) {
        int numTotalPrestamos = rs.getInt("num_prestamos");
        JOptionPane.showMessageDialog(this, "Número total de préstamos: " + numTotalPrestamos);
    } else {
        // Si no se encuentran resultados, muestra un mensaje
        JOptionPane.showMessageDialog(this, "No se encontraron préstamos.");
    }

    // Cierra la conexión
    cn.close();
} catch (Exception ex) {
    JOptionPane.showMessageDialog(this, ex.getMessage());
}

    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
// Asumiendo que tienes una clase ConectaDB que maneja la conexión a la base de datos.
Connection cn = ConectaDB.conexion();
try {
    // Consulta SQL para sumar el número total de préstamos hechos por un usuario específico
    String query = "SELECT COUNT(*) AS num_prestamos FROM Prestamos WHERE usuario_id = ?";

    // Preparar la declaración SQL con un parámetro para el ID de empleado
    PreparedStatement pst = cn.prepareStatement(query);
    pst.setInt(1, Integer.parseInt(jTextField2.getText()));  // Campo de texto para el ID de usuario

    // Ejecutar la consulta
    ResultSet rs = pst.executeQuery();

    // Si hay resultados, muestra el número total de préstamos del usuario
    if (rs.next()) {
        int numPrestamosUsuario = rs.getInt("num_prestamos");
        JOptionPane.showMessageDialog(this, "Número total de préstamos del usuario: " + numPrestamosUsuario);
    } else {
        // Si no se encuentran resultados, muestra un mensaje
        JOptionPane.showMessageDialog(this, "No se encontraron préstamos para este usuario.");
    }

    // Cierra la conexión
    cn.close();
} catch (Exception ex) {
    JOptionPane.showMessageDialog(this, ex.getMessage());
}
    }//GEN-LAST:event_jButton3ActionPerformed

    private void btnGrabar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGrabar1ActionPerformed
Connection cn = ConectaDB.conexion();
try {
    // Prepara la consulta SQL para seleccionar todos los datos de la tabla Prestamos
    PreparedStatement pst = cn.prepareStatement("SELECT id, empleado_id, usuario_id, fecha_prestamo, fecha_devolucion, ISBN, libro_numero_ejemplar, estado FROM Prestamos");

    // Ejecuta la consulta
    ResultSet rs = pst.executeQuery();

    // Limpia la tabla antes de agregar los datos (asumiendo que dt es el modelo de datos de la tabla)
    dt.setRowCount(0);

    // Mientras haya resultados, agrega cada fila a la tabla
    while (rs.next()) {
        dt.addRow(new Object[]{
            rs.getInt("id"),
            rs.getInt("empleado_id"),
            rs.getInt("usuario_id"),
            rs.getString("fecha_prestamo"),
            rs.getString("fecha_devolucion"),
            rs.getString("ISBN"),
            rs.getInt("libro_numero_ejemplar"),
            rs.getInt("estado")
        });
    }

    // Si no se encontraron resultados, muestra un mensaje
    if (dt.getRowCount() == 0) {
        JOptionPane.showMessageDialog(this, "No se encontraron registros en la tabla de préstamos.");
    }

    // Cierra la conexión
    cn.close();
} catch (Exception ex) {
    JOptionPane.showMessageDialog(this, ex.getMessage());
}
        
    }//GEN-LAST:event_btnGrabar1ActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGrabar;
    private javax.swing.JButton btnGrabar1;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JDialog dialogBusquedaCategoriaArticluos;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JTextField jTextField3;
    private javax.swing.JTextField jTextField4;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTable tblDialogTipoArticulo;
    private javax.swing.JTable tblP;
    private javax.swing.JTextField txtFechaIngreso;
    private javax.swing.JTextField txtPrecioCosto;
    private javax.swing.JTextField txtPrecioCosto1;
    private javax.swing.JLabel txtestado;
    // End of variables declaration//GEN-END:variables
    DefaultTableModel dt = new DefaultTableModel();
    DefaultTableModel dtDialogTipoArticulo = new DefaultTableModel();
   
}
