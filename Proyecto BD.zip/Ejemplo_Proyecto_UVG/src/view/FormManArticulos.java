/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package view;

import bd.ConectaDB;
import beans.Articulo;
import beans.Tipo_articulo;
import beans.dao.impl.DaoArticulo;
import beans.dao.impl.DaoTipo_articulo;
import beans.impl.DaoArticulosImpl;
import beans.impl.DaoTipoArticuloImpl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Hernanadez
 */
public class FormManArticulos extends javax.swing.JInternalFrame {
    DaoArticulo daoArticulo = new DaoArticulosImpl();
    DaoTipo_articulo daoTipo_articulo = new DaoTipoArticuloImpl();
    /**
     * Creates new form FormMantDepartamento
     */
    public FormManArticulos() {
        initComponents();
        dt.addColumn("ID_EMPLEADO");
        dt.addColumn("NOMBRE");
        dt.addColumn("DIRECCION");
        dt.addColumn("TELEFONO");
        dt.addColumn("PUESTO_ACTUAL");
        dt.addColumn("SALARIO");
        dt.addColumn("ESTADO");
        
        DefaultTableModel modelo = (DefaultTableModel) tbl.getModel();
;
        tbl.setModel(dt);
        }
public void limpiartabla(){
    
    dt.setRowCount(0);
    
    }
public void limpiar_campos()
{
    txtIdArticulo.setText("");
    txtIdTipoArticulo.setText("");
    txtrestado.setText("");
    txtDescripcionArticulo.setText("");
    txtPrecioVenta.setText("");
    txtPrecioCosto.setText("");
    txtFechaIngreso.setText("");
       
}
public void formateaTablaDialogCategorias()
{
    dtDialogTipoArticulo.addColumn("CODIGO");
    dtDialogTipoArticulo.addColumn("DESCRIPCION");
    
    tblDialogTipoArticulo.setModel(dtDialogTipoArticulo);
    tblDialogTipoArticulo.getColumnModel().getColumn(0).setPreferredWidth(30);
    tblDialogTipoArticulo.getColumnModel().getColumn(1).setPreferredWidth(100);
}

public void llenaTabla()
{
    try{
    ArrayList<Articulo> lista1 = new ArrayList<Articulo>();
    lista1 = (ArrayList)daoArticulo.query();
    dt.setRowCount(lista1.size());
    int i=0;
        for (Articulo lista11 : lista1) {
            dt.setValueAt(lista11.getId_articulo(), i, 0);
            dt.setValueAt(lista11.getDescripcion(), i, 1);
            dt.setValueAt(lista11.getPrecio_venta(), i, 2);
            dt.setValueAt(lista11.getPrecio_costo(), i, 3);
            dt.setValueAt(lista11.getCod_tipo_articulo(), i, 4);
            dt.setValueAt(lista11.getFecha_ingreso(), i, 5);
            i++;
        }
    tbl.setModel(dt);
    System.out.println();
    }catch(Exception e){
        JOptionPane.showMessageDialog(null, e.getMessage());
    }
}
public void llenaTablaDialogCategorias()
{
    try{
    ArrayList<Tipo_articulo> lista1 = new ArrayList<Tipo_articulo>();
    lista1 = (ArrayList)daoTipo_articulo.query();
    dtDialogTipoArticulo.setRowCount(lista1.size());
    int i=0;
        for (Tipo_articulo lista11 : lista1) {
            dtDialogTipoArticulo.setValueAt(lista11.getId_tipoarticulo(), i, 0);
            dtDialogTipoArticulo.setValueAt(lista11.getDescripcion_articulo(), i, 1);
          
            i++;
        }
    tblDialogTipoArticulo.setModel(dtDialogTipoArticulo);
    System.out.println();
    }catch(Exception e){
        JOptionPane.showMessageDialog(null, e.getMessage());
    }
}

public void obtieneCodigo()
{
    int cod = daoArticulo.getCodigo();
    cod = cod+1;
    txtIdArticulo.setText(String.valueOf(cod));
}
public void limpiaCampos()
{
    txtIdArticulo.setText("");
    txtDescripcionArticulo.setText("");
    txtPrecioVenta.setText("");
    txtPrecioCosto.setText("");
    txtFechaIngreso.setText("");
    txtIdTipoArticulo.setText("");
   
}
public void editableCodigo()
{
    txtIdArticulo.setEditable(false);
}
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        dialogBusquedaCategoriaArticluos = new javax.swing.JDialog();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblDialogTipoArticulo = new javax.swing.JTable();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl = new javax.swing.JTable();
        btnNuevo = new javax.swing.JButton();
        btnModificar = new javax.swing.JButton();
        btnEliminar = new javax.swing.JButton();
        btnGrabar = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtDescripcionArticulo = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtPrecioVenta = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txtPrecioCosto = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtFechaIngreso = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        btnBuscarCat = new javax.swing.JButton();
        txtestado = new javax.swing.JLabel();
        txtIdArticulo = new javax.swing.JTextField();
        txtIdTipoArticulo = new javax.swing.JTextField();
        txtrestado = new javax.swing.JTextField();
        btnGrabar1 = new javax.swing.JButton();

        tblDialogTipoArticulo.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tblDialogTipoArticulo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tblDialogTipoArticuloMousePressed(evt);
            }
        });
        jScrollPane2.setViewportView(tblDialogTipoArticulo);

        javax.swing.GroupLayout dialogBusquedaCategoriaArticluosLayout = new javax.swing.GroupLayout(dialogBusquedaCategoriaArticluos.getContentPane());
        dialogBusquedaCategoriaArticluos.getContentPane().setLayout(dialogBusquedaCategoriaArticluosLayout);
        dialogBusquedaCategoriaArticluosLayout.setHorizontalGroup(
            dialogBusquedaCategoriaArticluosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dialogBusquedaCategoriaArticluosLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 568, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        dialogBusquedaCategoriaArticluosLayout.setVerticalGroup(
            dialogBusquedaCategoriaArticluosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(dialogBusquedaCategoriaArticluosLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        setClosable(true);

        tbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        tbl.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tblMousePressed(evt);
            }
        });
        jScrollPane1.setViewportView(tbl);

        btnNuevo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/icono_nuevo1.jpg"))); // NOI18N
        btnNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNuevoActionPerformed(evt);
            }
        });

        btnModificar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/icono_modificar.png"))); // NOI18N
        btnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModificarActionPerformed(evt);
            }
        });

        btnEliminar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/icono_eliminar3.png"))); // NOI18N
        btnEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEliminarActionPerformed(evt);
            }
        });

        btnGrabar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/icono_guardar1.png"))); // NOI18N
        btnGrabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGrabarActionPerformed(evt);
            }
        });

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel5.setText("Personal");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(346, 346, 346)
                .addComponent(jLabel5)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel1.setText("Id Empleado");
        jLabel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel2.setText("Direccion");
        jLabel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtDescripcionArticulo.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel3.setText("Telefono");
        jLabel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtPrecioVenta.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setText("Puesto Actual");
        jLabel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtPrecioCosto.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel6.setText("Salario");
        jLabel6.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtFechaIngreso.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N

        jLabel8.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel8.setText("Nombre");
        jLabel8.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        btnBuscarCat.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        btnBuscarCat.setText("...");
        btnBuscarCat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBuscarCatActionPerformed(evt);
            }
        });

        txtestado.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        txtestado.setText("Estado");
        txtestado.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        txtIdArticulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdArticuloActionPerformed(evt);
            }
        });

        txtIdTipoArticulo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtIdTipoArticuloActionPerformed(evt);
            }
        });

        txtrestado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtrestadoActionPerformed(evt);
            }
        });

        btnGrabar1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/resources/lupa.jpg"))); // NOI18N
        btnGrabar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnGrabar1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jSeparator1, javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(btnNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnModificar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnGrabar, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnGrabar1, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGap(2, 2, 2)
                                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(18, 18, 18)
                                        .addComponent(txtIdArticulo, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(34, 34, 34))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel8)
                                            .addComponent(txtestado))
                                        .addGap(18, 18, 18)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(txtrestado, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                            .addGroup(layout.createSequentialGroup()
                                                .addComponent(txtIdTipoArticulo)
                                                .addGap(121, 121, 121)))))
                                .addComponent(btnBuscarCat)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txtFechaIngreso, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtPrecioCosto, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtPrecioVenta, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtDescripcionArticulo, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnNuevo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnEliminar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnGrabar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnModificar)
                    .addComponent(btnGrabar1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2)
                            .addComponent(txtDescripcionArticulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtIdArticulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel8)
                            .addComponent(btnBuscarCat)
                            .addComponent(jLabel3)
                            .addComponent(txtPrecioVenta, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtIdTipoArticulo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtestado)
                            .addComponent(txtrestado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(1, 1, 1)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addComponent(txtPrecioCosto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtFechaIngreso, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(20, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tblMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblMousePressed

        
    }//GEN-LAST:event_tblMousePressed

    private void btnNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNuevoActionPerformed
      // Asumiendo que tienes una clase ConectaDB que maneja la conexión a la base de datos.
Connection cn = ConectaDB.conexion();
try {
    // Crear una declaración para ejecutar la consulta SQL.
    Statement st = cn.createStatement();
    
    // Ejecutar la consulta para obtener el máximo ID de la tabla Libros.
    ResultSet rs = st.executeQuery("SELECT MAX(ISBN) FROM Libros");
    
    // Verificar si se encontraron resultados.
    if (rs.next()) {
        // Obtener el máximo ID y sumar 1 para el nuevo ID.
        String nuevoISBN = rs.getString(1);
        int nuevoNumero = Integer.parseInt(nuevoISBN.substring(3)) + 1;
        txtIdArticulo.setText("ISBN-" + nuevoNumero);
    } else {
        // Si no se encontraron resultados, establecer el ID inicial.
        txtIdArticulo.setText("ISBN-1");
    }
    
    // Limpiar los otros campos de texto.
    txtIdTipoArticulo.setText("");
    txtrestado.setText("");
    txtDescripcionArticulo.setText("");
    txtPrecioVenta.setText("");
    txtPrecioCosto.setText("");
    txtFechaIngreso.setText("");
    
    // Cerrar la conexión a la base de datos.
    cn.close();
    
    // Limpiar la tabla (asumiendo que tienes un método limpiartabla para esto).
    limpiartabla();
    
} catch (Exception ex) {
    // Mostrar un mensaje de error si ocurre una excepción.
    JOptionPane.showMessageDialog(this, ex.getMessage());
}

    }//GEN-LAST:event_btnNuevoActionPerformed

    private void btnGrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGrabarActionPerformed
        Connection cn = ConectaDB.conexion();
        try {
           PreparedStatement pst = cn.prepareStatement("INSERT INTO PersonalAdministrativo (id, nombre, direccion, telefono, puesto, salario, estado) VALUES (?, ?, ?, ?, ?, ?, ?)");
            pst.setString(1, txtIdArticulo.getText());
            pst.setString(2, txtIdTipoArticulo.getText());
            pst.setString(3, txtDescripcionArticulo.getText());
            pst.setString(4, txtPrecioVenta.getText());
            pst.setString(5, txtPrecioCosto.getText());
            pst.setString(6, txtFechaIngreso.getText());
            pst.setString(7, txtrestado.getText());
            
            
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Datos guardados con éxito");
            cn.close();
            limpiaCampos();
        
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
        }
     
    }//GEN-LAST:event_btnGrabarActionPerformed

    private void btnEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEliminarActionPerformed
      // Asumiendo que tienes una clase ConectaDB que maneja la conexión a la base de datos.
Connection cn = ConectaDB.conexion();
try {
    // Preparar la declaración SQL para eliminar datos en PersonalAdministrativo.
    PreparedStatement pst = cn.prepareStatement("DELETE FROM PersonalAdministrativo WHERE id = ?");
    
    // Establecer el valor del parámetro en la declaración preparada.
    pst.setInt(1, Integer.parseInt(txtIdArticulo.getText()));  // Campo de texto para el ID
    
    // Ejecutar la declaración SQL.
    pst.executeUpdate();
    
    // Mostrar un mensaje de éxito.
    JOptionPane.showMessageDialog(this, "Registro eliminado con éxito");
    
    // Cerrar la conexión a la base de datos.
    cn.close();
    
    // Limpiar los campos de texto (asumiendo que tienes un método limpiarCampos para esto).
    limpiaCampos();
    
    // Limpiar la tabla (asumiendo que tienes un método limpiarTabla para esto).
    limpiar_campos();

} catch (Exception ex) {
    // Mostrar un mensaje de error si ocurre una excepción.
    JOptionPane.showMessageDialog(this, ex.getMessage());
}

    }//GEN-LAST:event_btnEliminarActionPerformed

    private void tblDialogTipoArticuloMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblDialogTipoArticuloMousePressed
        int idx = tblDialogTipoArticulo.getSelectedRow();
        txtIdTipoArticulo.setText(String.valueOf(tblDialogTipoArticulo.getValueAt(idx, 0)));
        dialogBusquedaCategoriaArticluos.setVisible(false);
    }//GEN-LAST:event_tblDialogTipoArticuloMousePressed

    private void btnBuscarCatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBuscarCatActionPerformed
        dialogBusquedaCategoriaArticluos.setSize(620, 300);
        dialogBusquedaCategoriaArticluos.setLocationRelativeTo(this);
        dialogBusquedaCategoriaArticluos.setVisible(true);
        //formateaTablaDialogCategorias();
        llenaTablaDialogCategorias();
    }//GEN-LAST:event_btnBuscarCatActionPerformed

    private void btnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModificarActionPerformed
       // Asumiendo que tienes una clase ConectaDB que maneja la conexión a la base de datos.
Connection cn = ConectaDB.conexion();
try {
    // Preparar la declaración SQL para actualizar datos en PersonalAdministrativo.
    PreparedStatement pst = cn.prepareStatement("UPDATE PersonalAdministrativo SET nombre=?, direccion=?, telefono=?, puesto=?, salario=?, estado=? WHERE id = ?");
    
    // Establecer los valores de los parámetros en la declaración preparada.
    pst.setString(1, txtIdTipoArticulo.getText());         // Campo de texto para el Nombre
    pst.setString(2, txtDescripcionArticulo.getText());      // Campo de texto para la Dirección
    pst.setString(3, txtPrecioVenta.getText());       // Campo de texto para el Teléfono
    pst.setString(4, txtPrecioCosto.getText());         // Campo de texto para el Puesto
    pst.setString(5, txtFechaIngreso.getText());        // Campo de texto para el Salario
    pst.setString(6, txtrestado.getText());         // Campo de texto para el Estado
    pst.setInt(1, Integer.parseInt(txtIdArticulo.getText()));            // Campo de texto para el ID
    
    // Ejecutar la declaración SQL.
    pst.executeUpdate();
    
    // Mostrar un mensaje de éxito.
    JOptionPane.showMessageDialog(this, "Registro editado con éxito");
    
    // Cerrar la conexión a la base de datos.
    cn.close();
    
    // Limpiar los campos de texto (asumiendo que tienes un método limpiarCampos para esto).
    limpiaCampos();

} catch (Exception ex) {
    // Mostrar un mensaje de error si ocurre una excepción.
    JOptionPane.showMessageDialog(this, ex.getMessage());
}

    }//GEN-LAST:event_btnModificarActionPerformed

    private void txtIdArticuloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdArticuloActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdArticuloActionPerformed

    private void txtIdTipoArticuloActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtIdTipoArticuloActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtIdTipoArticuloActionPerformed

    private void btnGrabar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnGrabar1ActionPerformed
       Connection cn = ConectaDB.conexion();
try {
    // Prepara la consulta SQL para seleccionar todos los datos de la tabla PersonalAdministrativo
    PreparedStatement pst = cn.prepareStatement("SELECT id, nombre, direccion, telefono, puesto, salario, estado FROM PersonalAdministrativo");

    // Ejecuta la consulta
    ResultSet rs = pst.executeQuery();

    // Limpia la tabla antes de agregar los datos (asumiendo que dt es el modelo de datos de la tabla)
    dt.setRowCount(0);

    // Mientras haya resultados, agrega cada fila a la tabla
    while (rs.next()) {
        dt.addRow(new Object[]{
            rs.getInt("id"),
            rs.getString("nombre"),
            rs.getString("direccion"),
            rs.getString("telefono"),
            rs.getString("puesto"),
            rs.getString("salario"),
            rs.getString("estado")
        });
    }

    // Si no se encontraron resultados, muestra un mensaje
    if (dt.getRowCount() == 0) {
        JOptionPane.showMessageDialog(this, "No se encontraron registros en la tabla de personal administrativo.");
    }

    // Cierra la conexión
    cn.close();
} catch (Exception ex) {
    JOptionPane.showMessageDialog(this, ex.getMessage());
}

    }//GEN-LAST:event_btnGrabar1ActionPerformed

    private void txtrestadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtrestadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtrestadoActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBuscarCat;
    private javax.swing.JButton btnEliminar;
    private javax.swing.JButton btnGrabar;
    private javax.swing.JButton btnGrabar1;
    private javax.swing.JButton btnModificar;
    private javax.swing.JButton btnNuevo;
    private javax.swing.JDialog dialogBusquedaCategoriaArticluos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTable tbl;
    private javax.swing.JTable tblDialogTipoArticulo;
    private javax.swing.JTextField txtDescripcionArticulo;
    private javax.swing.JTextField txtFechaIngreso;
    private javax.swing.JTextField txtIdArticulo;
    private javax.swing.JTextField txtIdTipoArticulo;
    private javax.swing.JTextField txtPrecioCosto;
    private javax.swing.JTextField txtPrecioVenta;
    private javax.swing.JLabel txtestado;
    private javax.swing.JTextField txtrestado;
    // End of variables declaration//GEN-END:variables
    DefaultTableModel dt = new DefaultTableModel();
    DefaultTableModel dtDialogTipoArticulo = new DefaultTableModel();
   
}
