/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Windows 10
 */
public class ConectaDB {
    static String dato;
    static String usuario="ClaseSQL";
    static String  password = "123";
    static String url="jdbc:sqlserver://192.168.118.234:1433; databaseName=Universidad";
    public static Connection conexion(){
        Connection cn = null;
        try
        {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            cn = DriverManager.getConnection(url,usuario,password);
        }catch(ClassNotFoundException | SQLException ex)
        {
            javax.swing.JOptionPane.showMessageDialog(null, ex.getMessage()); 
        }
        return cn;
    }
}
